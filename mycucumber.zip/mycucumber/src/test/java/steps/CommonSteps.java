package steps;

import io.cucumber.java.After;
import io.cucumber.java.Before;

// se ejecutan para todos los escenarios
public class CommonSteps {

	// la ejecucion de los Before se ejecutan en orden 0,1,2,3...
	@Before(order = 0)
	public void setUp1() {
		System.out.println("Before orden 0");
	}
	@Before(order = 1)
	public void setUp2() {
		System.out.println("Before orden 1");
	}
	
	
	// la ejecucion de los afeter se ejecutan en orden ...3,2,1.0
	@After(order = 1)
	public void tearDown1() {
		System.out.println("... after order 1");
	}
	@After(order = 0)
	public void tearDown0() {
		System.out.println("... after order 0");
	}
	
	
}
