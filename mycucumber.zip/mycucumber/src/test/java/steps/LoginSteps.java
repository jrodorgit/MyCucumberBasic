package steps;

import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;

public class LoginSteps {

	/**
	public LoginSteps(CommonSteps obj) {
		
	}**/
	
	@Given("login page")
	public void login_page() {
	    System.out.println("login_page");
	}

	@When("intro user {string} and pass {string}")
	public void intro_user_and_pass(String user, String pass) {
		 System.out.println("intro_user_and_pass: "+user+"/"+ pass);
	}

	@Then("home page display")
	public void home_page_display() {
		System.out.println("home_page_display");
	}
	
	@Then("error page display")
	public void error_page_display() {
		System.out.println("error_page_display");
	}

}
