package steps;

import io.cucumber.java.After;
import io.cucumber.java.Before;

// Hooks definidos por tags que se pueden ejecutar en un escenario.
public class TaggedHooks {
	// la ejecucion de los Before se ejecutan en orden 0,1,2,3...
	// cuidado que el orden es compartido por los hooks comunes
	@Before(value = "@hookTagBefore1", order = 0)
	public void hookTagBefore1() {
		System.out.println("hookTagBefore1 orden 0");
	}
	
	@Before(value = "@hookTagBefore2", order = 1)
	public void hookTagBefore2() {
		System.out.println("hookTagBefore2 orden 1");
	}
	
	// la ejecucion de los afeter se ejecutan en orden ...3,2,1,0
	// cuidado que el orden es compartido por los hooks comunes
	@After(value = "@hookTag1After", order = 0)
	public void hookTag1After() {
		System.out.println("hookTag1After orden 0");
	}
	
	@After(value = "@hookTag2After", order = 1)
	public void hookTag2After() {
		System.out.println("hookTag2After orden 1");
	}
}
