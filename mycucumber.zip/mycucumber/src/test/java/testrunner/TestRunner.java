package testrunner;

import org.junit.runner.RunWith;

import io.cucumber.junit.Cucumber;
import io.cucumber.junit.CucumberOptions;

@RunWith(Cucumber.class)
@CucumberOptions(
			features = {"features"}, // features a ejecutar
			glue = {"steps"}, //archivo con los pasos que ejecutaran los diferentes escenarios
			plugin = {"pretty", "html:Report"}, // configuración de plugins de reporte de ejecucion
			dryRun = false, // false ejecuta los escenarios, true para solo sacar los idl de los pasos que no esten definidos.
			tags = "@Regresion or @Otros" // tags asociados a escenarios que se ejecutaran admite operadores OR y AND "@Regresion and @Aceptacion"
			//name = {"Fail Login"} // ejecutar un escenario por su nombre
			)
public class TestRunner {

}
